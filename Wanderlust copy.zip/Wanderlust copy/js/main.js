$('input[data-toggle="toggle"]').bootstrapToggle({
    onlabel: '',  // Set this to your desired label
    offlabel: '' // Set this to your desired label
});
